import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Test class for the MarbleSolitaireTextView implementation.
 * Tests rendering of game boards in various states and configurations.
 */
public class MarbleSolitaireTextViewTest {
    private MarbleSolitaireModel model1;
    private MarbleSolitaireModel model2;
    private MarbleSolitaireModel model3;
    private MarbleSolitaireTextView view1;
    private MarbleSolitaireTextView view2;
    private MarbleSolitaireTextView view3;

    /**
     * Sets up test models and views before each test method.
     * Creates models with different configurations and corresponding views.
     */
    @Before
    public void setUp() {
        model1 = new EnglishSolitaireModel();
        model2 = new EnglishSolitaireModel(0, 4);
        model3 = new EnglishSolitaireModel(5);
        view1 = new MarbleSolitaireTextView(model1);
        view2 = new MarbleSolitaireTextView(model2);
        view3 = new MarbleSolitaireTextView(model3);
    }

    /**
     * Tests that constructor throws exception for null model.
     */
    @Test(expected = IllegalArgumentException.class)
    public void testNullModelConstructor() {
        new MarbleSolitaireTextView(null);
    }

    /**
     * Tests toString renders default board correctly.
     */
    @Test
    public void testToStringDefaultBoard() {
        String expected =
                "    O O O\n" +
                        "    O O O\n" +
                        "O O O O O O O\n" +
                        "O O O _ O O O\n" +
                        "O O O O O O O\n" +
                        "    O O O\n" +
                        "    O O O";
        assertEquals(expected, view1.toString());
    }

    /**
     * Tests toString with custom empty position.
     */
    @Test
    public void testToStringCustomEmptyPosition() {
        String expected =
                "    O O _\n" +
                        "    O O O\n" +
                        "O O O O O O O\n" +
                        "O O O O O O O\n" +
                        "O O O O O O O\n" +
                        "    O O O\n" +
                        "    O O O";
        assertEquals(expected, view2.toString());
    }

    /**
     * Tests toString after a move has been made.
     */
    @Test
    public void testToStringAfterMove() {
        model1.move(3, 1, 3, 3);
        String expected =
                "    O O O\n" +
                        "    O O O\n" +
                        "O O O O O O O\n" +
                        "O _ _ O O O O\n" +
                        "O O O O O O O\n" +
                        "    O O O\n" +
                        "    O O O";
        assertEquals(expected, view1.toString());
    }

    /**
     * Tests toString after multiple moves.
     */
    @Test
    public void testToStringMultipleMoves() {
        model1.move(3, 1, 3, 3);
        model1.move(3, 4, 3, 2);
        model1.move(3, 6, 3, 4);
        String expected =
                "    O O O\n" +
                        "    O O O\n" +
                        "O O O O O O O\n" +
                        "O _ O _ O _ _\n" +
                        "O O O O O O O\n" +
                        "    O O O\n" +
                        "    O O O";
        assertEquals(expected, view1.toString());
    }

    /**
     * Tests toString with larger board (arm thickness 5).
     */
    @Test
    public void testToStringLargerBoard() {
        String line1 = "        O O O O O";
        String line2 = "        O O O O O";
        String line3 = "        O O O O O";
        String line4 = "        O O O O O";
        String line5 = "O O O O O O O O O O O O O";
        String line6 = "O O O O O O O O O O O O O";
        String line7 = "O O O O O O _ O O O O O O";
        String line8 = "O O O O O O O O O O O O O";
        String line9 = "O O O O O O O O O O O O O";
        String line10 = "        O O O O O";
        String line11 = "        O O O O O";
        String line12 = "        O O O O O";
        String line13 = "        O O O O O";

        String expected = String.join("\n",
                line1, line2, line3, line4, line5, line6, line7,
                line8, line9, line10, line11, line12, line13);

        assertEquals(expected, view3.toString());
    }

    /**
     * Tests that rendered board has no trailing spaces on any line.
     */
    @Test
    public void testToStringNoTrailingSpaces() {
        String result = view1.toString();
        String[] lines = result.split("\n");

        // Check each line for trailing spaces
        for (int i = 0; i < lines.length; i++) {
            assertFalse("Line " + i + " has trailing spaces",
                    lines[i].endsWith(" "));
        }
    }

    /**
     * Tests that rendered board has no trailing newline.
     */
    @Test
    public void testToStringNoTrailingNewline() {
        String result = view1.toString();
        assertFalse("Result should not end with newline",
                result.endsWith("\n"));
    }

    /**
     * Tests correct spacing in rendered board.
     */
    @Test
    public void testToStringCorrectSpacing() {
        String result = view1.toString();
        String[] lines = result.split("\n");

        // First line should start with 4 spaces
        assertTrue(lines[0].startsWith("    "));

        // Third line (full row) should not start with spaces
        assertFalse(lines[2].startsWith(" "));

        // Check that slots are separated by single spaces
        assertTrue(lines[0].contains("O O O"));
        assertFalse(lines[0].contains("O  O")); // No double spaces
    }

    /**
     * Tests rendering of minimal board (arm thickness 1).
     */
    @Test
    public void testToStringArmThickness1() {
        MarbleSolitaireModel smallModel = new EnglishSolitaireModel(1);
        MarbleSolitaireTextView smallView = new MarbleSolitaireTextView(smallModel);
        assertEquals("_", smallView.toString());
    }

    /**
     * Tests rendering after moves that affect corner areas.
     */
    @Test
    public void testToStringCornerMove() {
        // Make moves that affect the corners of the plus shape
        model1.move(1, 3, 3, 3);
        model1.move(2, 1, 2, 3);

        String expected =
                "    O O O\n" +
                        "    O _ O\n" +
                        "O _ _ O O O O\n" +
                        "O O O O O O O\n" +
                        "O O O O O O O\n" +
                        "    O O O\n" +
                        "    O O O";
        assertEquals(expected, view1.toString());
    }
}